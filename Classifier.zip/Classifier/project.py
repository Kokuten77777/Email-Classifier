import glob
import os
import math


def load_data(directory):
    x = []
    y = []
    for f in glob.glob(os.path.join(directory,"HAM.*.txt")):
        with open( f, 'r')as file:
            x.append(file.read())
            y.append(0)
    for f in glob.glob(os.path.join(directory,"SPAM.*.txt")):
        with open( f, 'r')as file:
            x.append(file.read())
            y.append(1)
    return x,y

def nb_train(x, y):
    ham_count = y.count(0)
    spam_count = y.count(1)
    string_punc = "!\"#$%&'()*+,-./:;<=>?@[\]^_`{|}~"

    ham_fd = {}
    spam_fd = {}

    for i,textfile in enumerate(x):
        textfile = textfile.translate(str.maketrans('', '', string_punc)) #This is to remove punctuations from the text.
        for line in textfile.split("\n"):
            textfile_list = line.split(" ") # A simple text tokenizer
            for word in textfile_list:
                if word not in ham_fd and (word != ""):
                    ham_fd[word] = 0
                if word not in spam_fd and (word != ""):
                    spam_fd[word] = 0
                if y[i] == 0 and (word != ""):
                    ham_fd[word] += 1
                if y[i] == 1 and (word != ""):
                    spam_fd[word] +=1
    model = {'ham_count':ham_count,'spam_count':spam_count,'ham_fd':ham_fd,'spam_fd':spam_fd}
    return model

def nb_test(docs, trained_model, use_log = False, smoothing = False):
    results = []
    ham_prior = (trained_model['ham_count'])/(trained_model['ham_count']+trained_model['spam_count'])
    spam_prior = (trained_model['spam_count'])/(trained_model['ham_count']+trained_model['spam_count'])
    vocab_total = len(trained_model['spam_fd']) # or len(trained_model['ham_fd'])
    ham_vocabTotal = sum(trained_model['ham_fd'].values())
    spam_vocabTotal = sum(trained_model['spam_fd'].values())

    for textfile in docs:
        ham_score = ham_prior if use_log == False else math.log(ham_prior)
        spam_score = spam_prior if use_log == False else math.log(spam_prior)
        for line in textfile.split("\n"):
            textfile_list = line.split(" ") # A simple text tokenizer
            for word in textfile_list:
                if word not in (trained_model["spam_fd"] or trained_model["ham_fd"]): # This is to check if the word exists in our Dictionary
                    pass
                else:
                    if use_log == True:
                        if smoothing == False:
                            intermediate_ham = math.log((trained_model['ham_fd'][word])/(ham_vocabTotal)) if trained_model['ham_fd'][word] > 0 else -math.inf
                            intermediate_spam = math.log((trained_model['spam_fd'][word])/(spam_vocabTotal)) if trained_model['spam_fd'][word] > 0 else -math.inf
                        else:
                           intermediate_ham = math.log((trained_model['ham_fd'][word]+ smoothing)/(ham_vocabTotal + (smoothing*vocab_total)))
                           intermediate_spam = math.log((trained_model['spam_fd'][word]+ smoothing)/(spam_vocabTotal + (smoothing*vocab_total))) 
                        ham_score += intermediate_ham
                        spam_score += intermediate_spam
                    else:
                        ham_score *= (trained_model['ham_fd'][word]+ smoothing)/(ham_vocabTotal + (smoothing*vocab_total))
                        spam_score *= (trained_model['spam_fd'][word]+ smoothing)/(spam_vocabTotal + (smoothing*vocab_total))
        if ham_score >= spam_score:
            results.append(0)
        else:
            results.append(1)
    return results


def f_score(y_true, y_pred):
    #TP - y_true = 1, y_pred = 1
    #TN - y_true = 0, y_pred = 0
    #FP - y_true = 1, y_pred = 0
    #FN - y_true = 0, y_pred = 1
    TP = TN = FP = FN = 0
    for i in range(len(y_true)):
        if (y_true[i] == 1) and (y_pred[i] == 1):
            TP +=1
        elif (y_true[i] == 0) and (y_pred[i] == 0):
            TN +=1
        elif (y_true[i] == 1) and (y_pred[i] == 0):
            FP +=1
        else:
            FN +=1
    recall = TP/(TP+FN)
    precision = TP/(TP+FP)
    fscore = 2*((precision*recall)/(precision+recall))
    return fscore 
def accuracy(y_true, y_pred):
    #accuarcy = correct predictions/total predictions
    correct_pred = 0
    total_pred = len(y_true)
    for i in range(len(y_true)):
        if(y_true[i] == y_pred[i]):
            correct_pred +=1
    return (correct_pred/total_pred)

x_train, y_train = load_data("SPAM_training_set")
x_test, y_test = load_data("SPAM_test_set")
model = nb_train(x_train, y_train)
y_pred = nb_test(x_test, model, use_log = True, smoothing = True)
print(f_score(y_test,y_pred))
y_pred = nb_test(x_test, model, use_log = True, smoothing = False)
print(f_score(y_test,y_pred))
y_pred = nb_test(x_test, model, use_log = False, smoothing = True)
print(f_score(y_test,y_pred))
y_pred = nb_test(x_test, model, use_log = False, smoothing = False)
print(f_score(y_test,y_pred))


